# discourse-sidebar-categories


Adds categories to the left side of the site and html arbitrary code.
 

## How to Install this Plugin

To install Discourse Plugin - https://meta.discourse.org/t/install-a-plugin/19157

The plugin was not intended to work on the mobile version. 

# License

MIT
